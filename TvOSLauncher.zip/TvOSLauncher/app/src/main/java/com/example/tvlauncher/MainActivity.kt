package com.example.tvlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BackHandler(true) { /* на домашнем экране «Назад» ничего не делает */ }
            LauncherScreen(resumeTick) { launchApp(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++ // обновляем список приложений при возврате на главный экран
    }

    private fun launchApp(app: AppEntry) {
        try {
            startActivity(app.intent)
        } catch (_: Exception) {
        }
    }
}

data class AppEntry(
    val label: String,
    val pkg: String,
    val intent: Intent,
    val image: ImageBitmap,
    val isBanner: Boolean,
)

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    fun query(cat: String) =
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)

    val found = query(Intent.CATEGORY_LEANBACK_LAUNCHER)
        .ifEmpty { query(Intent.CATEGORY_LAUNCHER) }

    return found
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val ai = ri.activityInfo
            val banner = ai.loadBanner(pm) ?: ai.applicationInfo.loadBanner(pm)
            val bmp = if (banner != null) banner.toBitmap(320, 180)
            else ri.loadIcon(pm).toBitmap(192, 192)
            AppEntry(
                label = ri.loadLabel(pm).toString(),
                pkg = ai.packageName,
                intent = Intent(Intent.ACTION_MAIN)
                    .setComponent(ComponentName(ai.packageName, ai.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
                image = bmp.asImageBitmap(),
                isBanner = banner != null,
            )
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun LauncherScreen(tick: Int, onLaunch: (AppEntry) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    LaunchedEffect(tick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }

    val clock by produceState("") {
        while (true) {
            value = SimpleDateFormat("EEE, d MMMM   HH:mm", Locale.getDefault()).format(Date())
            delay(10_000)
        }
    }

    val firstItem = remember { FocusRequester() }
    LaunchedEffect(apps.isNotEmpty()) {
        if (apps.isNotEmpty()) {
            delay(150)
            try { firstItem.requestFocus() } catch (_: Exception) {}
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF3B2F72), Color(0xFF15183A), Color(0xFF06060C))
                )
            )
    ) {
        BasicText(
            "Приложения",
            modifier = Modifier.align(Alignment.TopStart).padding(start = 80.dp, top = 48.dp),
            style = TextStyle(color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold),
        )
        BasicText(
            clock,
            modifier = Modifier.align(Alignment.TopEnd).padding(end = 80.dp, top = 54.dp),
            style = TextStyle(color = Color.White.copy(alpha = 0.75f), fontSize = 22.sp),
        )

        LazyRow(
            modifier = Modifier.align(Alignment.Center).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 80.dp, vertical = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(30.dp),
        ) {
            itemsIndexed(apps, key = { _, a -> a.pkg }) { i, app ->
                AppCard(app, if (i == 0) firstItem else null, onLaunch)
            }
        }
    }
}

@Composable
fun AppCard(app: AppEntry, requester: FocusRequester?, onLaunch: (AppEntry) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.12f else 1f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium),
        label = "scale",
    )
    val labelAlpha by animateFloatAsState(if (focused) 1f else 0f, label = "label")
    val shape = RoundedCornerShape(22.dp)

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(264.dp)) {
        Box(
            Modifier
                .size(264.dp, 149.dp)
                .then(if (requester != null) Modifier.focusRequester(requester) else Modifier)
                .onFocusChanged { focused = it.isFocused }
                .clickable { onLaunch(app) }
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    shadowElevation = if (focused) 60f else 0f
                    this.shape = shape
                    clip = true
                }
                .background(Color(0xFF2A2A30))
                .then(if (focused) Modifier.border(3.dp, Color.White.copy(alpha = 0.9f), shape) else Modifier)
        ) {
            Image(
                bitmap = app.image,
                contentDescription = app.label,
                contentScale = if (app.isBanner) ContentScale.Crop else ContentScale.Fit,
                modifier = if (app.isBanner) Modifier.fillMaxSize()
                else Modifier.align(Alignment.Center).size(96.dp),
            )
            if (focused) {
                // лёгкий «глянцевый» блик, как на Apple TV
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.18f), Color.Transparent))
                    )
                )
            }
        }
        BasicText(
            app.label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 28.dp).alpha(labelAlpha),
            style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium),
        )
    }
}
