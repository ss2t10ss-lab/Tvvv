# TV Home — лаунчер в стиле tvOS для Android TV

## Как получить APK
**Вариант 1 — Android Studio:** File → Open → папка проекта → Build → Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

**Вариант 2 — GitHub Actions (без установки ничего на ПК):**
1. Создайте пустой репозиторий на github.com и загрузите в него содержимое этой папки.
2. Вкладка Actions → Build APK → Run workflow.
3. Скачайте APK из Artifacts.

## Установка на ТВ
adb connect IP_ТВ:5555 && adb install app-debug.apk
(или через флешку / приложение Send Files to TV)

## Сделать главным экраном
Настройки → Приложения → Приложения по умолчанию → Главный экран (или нажмите Home и выберите «TV Home» → Всегда).
На некоторых ТВ с Google TV замену домашнего экрана нужно включать через adb:
adb shell cmd package set-home-activity com.example.tvlauncher/.MainActivity
